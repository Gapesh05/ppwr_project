SYSTEM_PROMPT = "Summarize notes relevant to PPWR assessment; include any stated limitations or references. Return as a 'notes' string and 'restricted_substances' list."
