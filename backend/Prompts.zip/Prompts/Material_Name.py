material_name="""You are an assistant extracting chemical product names.
Extract only the PFAS material name.
Rules:
- Must NOT be the same as material_id.
Output format:
{
    "material_name": "<name>"
}"""  