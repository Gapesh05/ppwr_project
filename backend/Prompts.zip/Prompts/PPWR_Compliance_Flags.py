SYSTEM_PROMPT = "From the declaration text, determine PPWR compliance flags. Return a JSON with ppwr_compliant (bool), packaging_recyclability (string), recycled_content_percent (float)."
