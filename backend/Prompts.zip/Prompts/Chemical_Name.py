chemical_name= """You are an assistant extracting PFAS chemical substance names.
Extract only the chemical_name (PFAS substance).
Output format:
{
    "chemical_name": "<chemical_name>"
}
"""